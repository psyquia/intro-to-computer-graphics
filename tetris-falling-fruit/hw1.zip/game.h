#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <iostream>
#include <vector>
#include <time.h>
#include <ctime>
#include "shapes.h"
using namespace std;

class Game {
public:
  board * gBoard = new board();
  shape * aShape;
  int test = 0;
  bool keepChecking = false;
  Game(){
    srand (time(NULL));
    aShape = new shape(gBoard,rand()%6);
  }
  void tick(int time){
    if(time > 1){
      if(keepChecking){
        keepChecking = gBoard->matchCheck();
      }
      if(aShape->falling){
        aShape->fall(gBoard);
      }else{
        gBoard->rowCheck();
        keepChecking = gBoard->matchCheck();
        aShape = new shape(gBoard,rand()%6);
        if(aShape->collision(gBoard,'d')=='d'){
          exit(EXIT_SUCCESS);
        }
      }
    }
  }
  void restart(){
    gBoard = new board();
    aShape = new shape(gBoard,rand()%6);
  }
  int getScore(){
    return gBoard->score;
  }

  void draw(){
    gBoard->draw();
  }
  
  void move(char input){
    if(input=='a'){
      aShape->moveLeft(gBoard);
    }else if(input=='d'){
      aShape->moveRight(gBoard);
    }else if(input=='w'){
      aShape->rotate(gBoard);
    }else if(input=='s'){
      aShape->fall(gBoard);
    }
  }
};
